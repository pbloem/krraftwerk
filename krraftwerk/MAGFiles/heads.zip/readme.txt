#File
#Column number	Column description

2016 KDD Cup Selected Affiliations
1	Affiliation ID
2	Affiliation name

2016 KDD Cup Selected Papers
1	Paper ID
2	Original paper title
